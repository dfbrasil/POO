from enum import Enum

class Type_Flight(Enum):
    national = 'national'
    international = 'international'
        


