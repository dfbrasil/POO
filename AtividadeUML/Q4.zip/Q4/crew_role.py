from enum import Enum

class Crew_Role(Enum):
    commander = 'commander'
    co_pilot = 'co_pilot'
    flight_attendant = 'flight_attendant'
    flight_mecanic = 'flight_mecanic'
        


