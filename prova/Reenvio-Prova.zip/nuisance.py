import abc


class Nuisance(abc.ABC):

    """ 
    Método Abstrato
    """

    @abc.abstractmethod
    def annoy():
        pass
